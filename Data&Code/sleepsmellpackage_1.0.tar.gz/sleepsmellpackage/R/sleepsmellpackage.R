#' @title Sleep & Smell Dataset
#'
#' @description
#'
#' \strong{Sample} - \emph{study}
#' \itemize{
#' \item 1 = Sample 1
#' \item 2 = Sample 2
#' \item 3 = Sample 3
#' }
#'
#' \strong{Sex Coding} - \emph{sex}
#' \itemize{
#'   \item 0 = female
#'   \item 1 = male
#'}
#'
#' \strong{Scent Coding} - \emph{shirt}
#' \itemize{
#'   \item 0 = control
#'   \item 1 = partner
#' }
#'
#' \strong{Relationship Length} - \emph{rel.length} -- Relationship length reported in months
#'
#' \strong{Sleep Efficiency} - \emph{sleep.efficiency}
#' \itemize{
#'   \item A wrist-worn actigraphy monitor
#'   (Actiwatch 2, Philips Respironics)
#'   recorded participants’ sleep/wake intervals each night.
#'   Sleep Efficiency was calculated by dividing
#'   sleep time by total time in bed.
#'   \item The value was input as a percentage
#' }
#'
#' \strong{Perceived Sleep Quality} - \emph{perceived.sleep.quality}
#' \cr \cr Two items, \emph{sleep.quality.SR} & \emph{rested.SR}, were averaged
#' to form the measure of Perceived Sleep Quality \cr \cr
#' -- \emph{sleep.quality.SR}
#' \itemize{
#'   \item Last night, how would you rate your sleep quality overall?
#'   \item 1 = Very Bad
#'   \item 7 = Very Good
#' }
#' -- \emph{rested.SR}
#' \itemize{
#'   \item How well rested do you feel this morning?
#'   \item 1 = Very Unrested
#'   \item 7 = Very Rested
#' }
#'
#' \strong{Perceived Stress} - \emph{stress.2}
#' \cr \cr Two items, \emph{stress.today} & \emph{stress.tomorrow} were averaged
#' to form a measure of perceived stress \cr \cr
#' -- \emph{stress.today}
#' \itemize{
#' \item How stressful was your day today?
#' }
#' -- \emph{stress.tomorrow}
#' \itemize{
#' \item How stressful do you expect your day tomorrow will be?
#' }
#' -- Coding
#' \itemize{
#' \item 1 = Very Unstressful
#' \item 3 = Fairly Unstressful
#' \item 5 = Fairly Stressful
#' \item 7 = Very Stressful
#' }
#'
#'
#' \strong{Control Variable (control t-shirt type)} - \emph{control}
#' \itemize{
#' \item 0 = Stranger
#' \item 1 = Unworn
#' }
#'
#' \strong{Weeknight} - \emph{night}
#' \itemize{
#' \item 1 = Monday
#' \item 2 = Tuesday
#' \item 3 = Wednesday
#' \item 4 = Thursday
#' }
#'
#' \strong{Night Number} - \emph{night.num}
#' \itemize{
#'   \item 1,2 = control and 3,4 = partner \cr (regardless of scent exposure order)
#' }
#'
#' \strong{Condition} - \emph{condition}
#' \itemize{
#' \item 0 = control first
#' \item 1 = partner first
#' }
#'
#' \strong{Ethnicity Coding} - \emph{ethnicity}
#' \itemize{
#'   \item 1 = Aboriginal
#'   \item 2 = Arab
#'   \item 3 = Black
#'   \item 4 = Chinese
#'   \item 5 = Filipino
#'   \item 6 = Japanese
#'   \item 7 = Korean
#'   \item 8 = Latin American
#'   \item 9 = South Asian (East Indian, Pakistani)
#'   \item 10 = Southeast Asian (Vietnamese, Thai...)
#'   \item 11 = West Asian (Iranian, Afghan, Iraqi...)
#'   \item 12 = White
#'   \item 13 = Other
#' }
#'
#' \strong{Belief} - \emph{belief}
#' \itemize{
#'   \item Each night, participants were coded as believing the scent was their
#'   partner’s (1) or not believing the scent was their partner’s (0).
#' }
#'
#'
#'
#' \strong{Relationship Quality} - \emph{RS_overall, RS_trust,	RS_satisfaction,
#' 	RS_commitment,	RS_intimacy,	RS_passion,	RS_love
#' }
#' \itemize{
#'   \item Each variable is a subscale of the
#'   Perceived Relationship Quality Component. \emph{RS_overall} is the participant's measure on the entire scale \cr
#'   \cite \emph{-- (Fletcher, Simpson & Thomas, 2000)}
#' }
#'
#' \strong{Attachment Style} - \emph{AAQ_avoidance,	AAQ_ambivalence}
#' \itemize{
#'    \item Each variable is a subscale of the Adult Attachment Questionnaire \cr
#'    \cite \emph{-- (Simpson, Rholes & Phillips, 1996)}
#'   }
#'
#' \strong{Shirt Odor Related Variables} - \emph{pleasantness.odor, intensity.odor,
#' erotic.odor} -- Likert Scale used
#' \describe{
#'   \item{Pleasantness}{\itemize{
#'   \item 0 = Very unpleasant
#'   \item 7 = Very pleasant
#' }}
#' \item{Intensity}{\itemize{
#'   \item 0 = Odorless
#'   \item 7 = Very strong odor
#' }}
#' \item{Erotic}{\itemize{
#'   \item 0 = Not at all erotic
#'   \item 7 = Very erotic
#' }}
#' }
#'
#' \strong{Onset Latency} - \emph{onset.latency}
#' \itemize{
#'   \item Onset latency is the amount of time taken to fall asleep for the first time at night
#' }
#'
#' \strong{Wake after sleep onset (WASO)} - \emph{WASO}
#' \itemize{
#'   \item WASO is the amount of time an individual
#'   is awake during the night after they have initially fallen asleep
#' }
#'
#'@details
#' External data files required for analysis: \emph{sleepandsmelldata.csv}  \cr
#'and \emph{wide-sleepandsmell.csv}
#'
#' @name sleepdata
#' @docType data
NULL
