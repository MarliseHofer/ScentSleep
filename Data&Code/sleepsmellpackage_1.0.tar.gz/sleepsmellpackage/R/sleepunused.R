#' @title Sleep & Smell - Unused Variables
#'
#' @description
#'
#' \strong{Time spent with partner} - \emph{rel.days.per.week,	rel.nights.per.week}
#' \itemize{
#'   \item \emph{rel.days.per.week} - How many days a week do you see your romantic partner,
#'   on average?
#'   \item \emph{rel.nights.per.week} - How many nights a week do you sleep in the same bed as your
#'   romantic partner, on average?
#' }
#'
#' \strong{Intention} - \emph{intentional.smell,	intentional.sleep,	intentional.give}
#' \describe{
#' \item{Questions regarding one's intentional use of smell in life}
#' {\itemize{
#'   \item \emph{intentional.smell} - How often have you intentionally smelled another person’s clothing
#'   to feel closer to him or her? (0-7 from Never to Frequently)
#'   \item \emph{intentional.sleep} - How often have you ever slept with (or worn to sleep) items
#'   belonging to another person (that hadn’t been laundered since it had
#'   been worn) because it smelled like him or her? (0-7 from Never to Frequently)
#'   \item \emph{intentional.give} - Have you ever given another person
#'   (or has another person taken) items belonging to you (that hadn’t been laundered since it had been
#'   worn) because it smelled like you? (Yes/No reponse)
#' }}
#' }
#'
#' \strong{Awake} - \emph{num.awake}
#' \itemize{
#'   \item Variable indicates the number of times the participant woke up during
#'   their sleep interval
#' }
#'
#' \strong{Birth Control} - \emph{birth.control.2}
#' \itemize{
#'   \item Asked whether the participant was using hormonal birth control specifically (women only)
#'   \item 0 = No
#'   \item 1 = Yes
#' }
#'
#' @name sleepdata_unused
#' @docType data
NULL
